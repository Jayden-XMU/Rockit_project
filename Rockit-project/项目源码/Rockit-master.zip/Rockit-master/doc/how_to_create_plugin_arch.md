# how to create plugin arch


## references
[1] [构建自己的C/C++插件开发框架](https://blog.csdn.net/pizi0475/article/details/5471637)
[2] [值得推荐的C/C++框架和库](https://blog.csdn.net/qq_21950929/article/details/78668870)
[3] [sumeetchhetri/ffead-cpp](https://github.com/sumeetchhetri/ffead-cpp)
[4] [orocos-toolchain/log4cpp](https://github.com/orocos-toolchain/log4cpp)
[5] [MT6797/frameworks](https://github.com/MT6797/frameworks)
[6] [VLC hacking guide](https://wiki.videolan.org/Hacker_Guide)