#!/bin/bash
set -e
./astyle --quiet --options=astylerc ../*.cpp ../*.c ../*.h

